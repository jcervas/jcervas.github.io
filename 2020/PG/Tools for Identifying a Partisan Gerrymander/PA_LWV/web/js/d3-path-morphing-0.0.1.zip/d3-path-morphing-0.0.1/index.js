export {default as morphPath} from "./src/morphPath";
